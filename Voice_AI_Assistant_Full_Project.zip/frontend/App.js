
import { useState } from "react";
import "./App.css";

function App() {
  const [text, setText] = useState("");
  const [chat, setChat] = useState([]);

  const startListening = () => {
    const recognition = new window.webkitSpeechRecognition();
    recognition.lang = "en-US";
    recognition.start();
    recognition.onresult = (event) => {
      const spokenText = event.results[0][0].transcript;
      sendMessage(spokenText);
    };
  };

  const speak = (message) => {
    const speech = new SpeechSynthesisUtterance(message);
    window.speechSynthesis.speak(speech);
  };

  const sendMessage = async (msg) => {
    setChat(prev => [...prev, { sender: "You", text: msg }]);
    const res = await fetch("http://127.0.0.1:5000/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: msg })
    });
    const data = await res.json();
    setChat(prev => [...prev, { sender: "Bot", text: data.reply }]);
    speak(data.reply);
  };

  return (
    <div className="container">
      <h2>Gemini Voice AI</h2>
      <div className="chat">
        {chat.map((c,i) => <p key={i}><b>{c.sender}:</b> {c.text}</p>)}
      </div>
      <input onChange={e => setText(e.target.value)} value={text} />
      <button onClick={() => sendMessage(text)}>Send</button>
      <button onClick={startListening}>Speak</button>
    </div>
  );
}

export default App;
